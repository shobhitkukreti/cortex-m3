#include<stdio.h>
#include<stdarg.h>
#include <stdint.h>

void main()
{
uint16_t buf=0x3,tmp=0x01;

buf=buf<<8;
tmp|=buf;
printf("%x\n",tmp);


}
